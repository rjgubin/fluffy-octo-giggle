<?php
//config

$server = "localhost";
$user = "root";
$password = "";
$database = "address_book";

//Establishing Connecting to SQL
$connection = mysqli_connect($server, $user, $password, $database);

//Check connection
if (!$connection) {
    die ("Total Fail" . mysqli_connect_error());
} else {
    echo "Connection Successful";
}

//SQL COMMAND
$sql_command = "TRUNCATE TABLE people";
if (mysqli_query($connection, $sql_command)) {
    echo "SQL COMMAND EXECUTED";
}
else {
    echo "SQL FAILURE" . mysqli_error($connection);
}
//Check SQL Commands




