<form action="data_insert.php" method="post"
      <label>ID</label><br>
<input type="text" name="id">
<br><br>

<label>Name</label><br>
<input type="text" name="name">
<br><br>

<label>Lastname</label><br>
<input type="text" name="lastname">
<br><br>

<label>Telephone</label><br>
<input type="text" name="telephone">
<br><br>

<label>email</label><br>
<input type="text" name="email">
<br><br>

<label>Address</label><br>
<input type="text" name="address">
<br><br>



<input type="submit" value="Submit">

</form>


