<?php
//config

$server = "localhost";
$user = "root";
$password = "";
$database = "address_book";

//Establishing Connecting to SQL
$connection = mysqli_connect($server, $user, $password, $database);

//Check connection
if (!$connection) {
    die ("Total Fail" . mysqli_connect_error());
} else {
    echo "Connection Successful";
}

//SQL COMMAND
$sql_command = "SELECT + FROM people";
$action = mysqli_query($connection, $sql_command);
while ($line = mysqli_fetch_assoc($action)) {
    echo "ID: " . $line["ID"] ."<br>";
    echo "Name: " . $line["name"] . "<br>";
    echo "Lastname: " . $line["lastname"] . "<br>";
    echo "Telephone: " . $line["telephone"] . "<br>";
    echo "email: " . $line["email"] . "<br>";
    echo "<hr>";
}



//Check SQL Commands




