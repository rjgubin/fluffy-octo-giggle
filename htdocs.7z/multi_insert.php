<?php
//config

$server = "localhost";
$user = "root";
$password = "";
$database = "address_book";

//Establishing Connecting to SQL
$connection = mysqli_connect($server, $user, $password, $database);

//Check connection
if (!$connection) {
    die ("Total Fail" . mysqli_connect_error());
} else {
    echo "Connection Successful";
}

//SQL COMMAND
$sql_command ="INSERT INTO people(id, name, lastname, telephone, email, address)
VALUES (NULL,'Alex', 'Sam',451234, 'mail2@mail.com', 'Main drive 203' )";



//Check SQL Commands

if (mysqli_multi_query($connection, $sql_command)) {
    $last_entry = mysqli_insert_id($connection);
    echo "SQL Command Ok, last ID: ", $last_entry. "<hr>";
}
else {
    echo "SQL ERROR" . mysqli_error($connection);
}


