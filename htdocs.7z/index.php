<?php
//config

$server = "localhost";
$user = "root";
$password = "";
$database = "address_book";

//Establishing Connecting to SQL
$connection = mysqli_connect($server, $user, $password, $database);

//Check connection
if (!$connection) {
    die ("Total Fail" . mysqli_connect_error());
} else {
    echo "Connection Successful";
}

//SQL COMMAND
$sql_command = "CREATE TABLE people(
id INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
name VARCHAR (31) NOT NULL,
lastname VARCHAR (31) NOT NULL,
telephone INT,
email VARCHAR (98),
address VARCHAR (99),
meta TIMESTAMP 
)";


//Check SQL Commands

if (mysqli_query($connection, $sql_command)) {
    echo "SQL Command Ok";
}
else {
    echo "SQL ERROR" . mysqli_error($connection);
}

