<?php
//config

$server = "localhost";
$user = "root";
$password = "";
$database = "address_book";

//Establishing Connecting to SQL
$connection = mysqli_connect($server, $user, $password, $database);

//Check connection
if (!$connection) {
    die ("Total Fail" . mysqli_connect_error());
} else {
    echo "Connection Successful";
}

//SQL COMMAND
$sql_command = "SELECT * FROM people";
$action = mysqli_query($connection, $sql_command);
echo "<h1>Results: </h1>";
echo "<table width='80%' cellspan='2' border='2'><tr>";
echo "<td>ID</td>";
echo "<td>Name</td>";
echo "<td>Lastname</td>";
echo "<td>telephone</td>";
echo "<td>email</td>";
echo "<td>address</td>";
echo "<td>meta</td></tr>";
while ($line = mysqli_fetch_assoc($action)) {
    echo "<td>" . $line["id"] .
    "</td><td>" . $line["name"].
        "</td><td>" . $line["lastname"].
        "</td><td>" . $line["telephone"].
        "</td><td>" . $line["email"].
        "</td><td>" . $line["address"].
        "</td><td>" . $line["meta"]. "</tr>";
}
echo "</table>";


//Check SQL Commands




